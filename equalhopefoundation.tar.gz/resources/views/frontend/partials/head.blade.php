<!-- Goodsoul_html/index-2.html  20 Nov 2019 03:27:59 GMT -->
<head>
<meta charset="utf-8">
<title>Equal Hope Foundation</title>

<link rel="shortcut icon" href=" {{ asset('frontend/images/favicon-2.png') }} " type="image/x-icon">
<link rel="icon" href="{{ asset('frontend/images/favicon-2.png') }}" type="image/x-icon">

<!-- Google Fonts -->
<link href="https://fonts.googleapis.com/css?family=Prata|Rubik:300,400,500,700&amp;display=swap" rel="stylesheet">

<!-- Stylesheets -->
<link href="frontend/css/bootstrap.css" rel="stylesheet">
<link href="frontend/css/jquery-ui.css" rel="stylesheet">
<link href="frontend/css/swiper.min.css" rel="stylesheet">
<link href="frontend/css/flaticon.css" rel="stylesheet">
<link href="frontend/css/font-awesome.css" rel="stylesheet">
<link href="frontend/css/animate.css" rel="stylesheet">
<link href="frontend/css/custom-animate.css" rel="stylesheet">
<link href="frontend/css/jquery.fancybox.min.css" rel="stylesheet">
<link href="frontend/css/owl.css" rel="stylesheet">
<link href="frontend/css/style.css" rel="stylesheet">
<link href="frontend/css/responsive.css" rel="stylesheet">

<!-- Responsive -->
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
<!--[if lt IE 9]><script src="https://cdnjs.cloudflare.com/ajax/libs/html5shiv/3.7.3/html5shiv.js"></script><![endif]-->
<!--[if lt IE 9]><script src="js/respond.js"></script><![endif]-->
</head>