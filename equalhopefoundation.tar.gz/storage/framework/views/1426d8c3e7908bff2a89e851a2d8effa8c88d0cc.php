<!-- JS -->
<script src="frontend/js/jquery.js"></script>
<script src="frontend/js/popper.min.js"></script>
<script src="frontend/js/bootstrap.min.js"></script>
<script src="frontend/js/TweenMax.min.js"></script>
<script src="frontend/js/wow.js"></script>
<script src="frontend/js/owl.js"></script>
<script src="frontend/js/appear.js"></script>
<script src="frontend/js/swiper.min.js"></script>
<script src="frontend/js/jquery.fancybox.js"></script>
<script src="frontend/js/menu-nav-btn.js"></script>
<script src="frontend/js/jquery-ui.js"></script>
<script src="frontend/js/jquery.countdown.min.js"></script>
<!-- Custom JS -->
<script src="frontend/js/script.js"></script><?php /**PATH /opt/lampp/htdocs/equalhopefoundation/resources/views/frontend/partials/scripts.blade.php ENDPATH**/ ?>